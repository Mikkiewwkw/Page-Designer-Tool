#config file containing credentials for RDS MySQL instance
db_username = "python_scripts"
db_password = "awfij9h971"
db_name = "ims"
